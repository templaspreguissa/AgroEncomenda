# AgroEncomenda

Site estático (HTML, CSS e JavaScript) que conecta produtores e compradores: catálogo de produtos, encomendas, envio de propostas e uma simulação de compra.

## Como rodar

Abra o arquivo `index.html` no navegador. Não há dependências nem etapa de build.

## Arquivos

- `index.html` — estrutura das páginas
- `style.css` — estilos
- `script.js` — lógica (login de demonstração, pedidos, propostas e simulação)

Os dados da demonstração ficam guardados apenas na sessão do navegador.
